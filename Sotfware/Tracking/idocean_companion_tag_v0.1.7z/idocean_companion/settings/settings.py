# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2019 schade <schade@schadelin-System>
#
# Distributed under terms of the MIT license.

"""
File dedicated to manage settings of the ROV IHM
Settings is a global singleton we will manange the ihm data
"""
import logging
import sys
import os

SCRIPT_CONF_JSON = "./settings/settings.json"

class Singleton(object):
    '''
    Singleton class dedicated to manage all settings of the ROV settings instance
    Class dedicated to store only one instance of the global main class
    '''
    _instances = {}

    def __new__(class_, *args, **kwargs):
        if class_ not in class_._instances:
            class_._instances[class_] = super(Singleton, class_).__new__(class_, *args, **kwargs)
        return class_._instances[class_]


class CTrackingSettings(Singleton):
    """
    Main class settings which herits from singleton
    This class manage the global settings of the application
    """
    def __str__(self):
        str_return = "-- ScriptConf --\n"
        for element in self.script_conf:
            str_return += "- " + element + " : " + str(self.script_conf[element]) + "\n"
        return str_return

    """
    Initialization of main dictionary retrieved from JSON
    """
    def __init__(self):
        # Variable dedicated to the script configuration
        self.script_conf = {}

        self.logger = None
        self.formatter = None
        self.logHandler = None

    """
    Load JSON settings
    """
    def load_from_json(self):
        import json
        # Check and read main configuration JSON file
        exist = os.path.isfile(SCRIPT_CONF_JSON)
        if exist:
            with open(SCRIPT_CONF_JSON, 'r') as f:
                config_json = json.load(f)
                self.script_conf = config_json
                print(self.script_conf)
        else:
            # Logger not yet created print it !
            print("Error JSON Main settings file not found {}".format(SCRIPT_CONF_JSON))
            sys.exit(0)

        return

    def save_to_json(self, path="./settings/"):
        import json
        if os.path.exists(path):
            if path[-1] == '/':
                pass
            else:
                path = path + "/"
            if os.path.exists(path + "settings.json"):
                open(path + "settings.json", 'w').close()

            with open(path+"settings.json", 'w') as json_file:
                json.dump(self.script_conf, json_file)

        else:
            self.logger.warning("Path to save %s not existing." % path) 
        
    """
    Load ARGS settings
    """
    def load_from_args(self, args):
        if args['--verbose']:
            self.script_conf['verbose'] = args['--verbose'] 
        else:
            pass

        if args['--loglvl'] is not None:
            self.script_conf['log_level'] = args['--loglvl']
        else:
            self.script_conf['log_level']

        if args['--output_folder'] is not None:
            if os.path.exists(args['--output_folder']):
                self.script_conf['output_folder'] = args['--output_folder']

        return

    """
    Create logger for the script instance
    """
    def create_logger(self):
        logpath = self.script_conf['path_output_save'] + 'mainLog.log'
        if not os.path.isfile(logpath):
            with open(logpath, 'w'):
                pass
        self.logger = logging.getLogger('rover_app')
        self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logHandler = logging.FileHandler(logpath)
        self.logStreamHand = logging.StreamHandler(sys.stdout)

        # Retrieve Log information
        if self.script_conf['log_level'] == "INFO":
            self.logger.setLevel(logging.INFO)
        elif self.script_conf['log_level'] == "DEBUG":
            self.logger.setLevel(logging.DEBUG)
        elif self.script_conf['log_level'] == "WARNING":
            self.logger.setLevel(logging.WARNING)
        elif self.script_conf['log_level'] == "ERROR":
            self.logger.setLevel(logging.ERROR)
        else:
            self.loglvl = "INFO"
            print("Unrecognized log level, default value INFO used")
            self.logger.setLevel(logging.INFO)
#            self.logHandler.setLevel(logging.INFO)
#            self.logStreamHand.setLevel(logging.INFO)

        self.logHandler.setFormatter(self.formatter)
        self.logStreamHand.setFormatter(self.formatter)
        self.logger.addHandler(self.logHandler)
        if self.script_conf['verbose']:
            self.logger.addHandler(self.logStreamHand)
        return

    """
    Function dedicated to check input at init
    """
    def check_input(self):
        # Check warterlinked ip adress
        if is_valid_ipv4_address(self.script_conf["waterlink_ip"]):
            self.waterlink_ip = "http://{}".format(self.script_conf["waterlink_ip"])
            self.logger.info("mainWaterlinked : waterlink url : {}".format(url_webgui))
        else:
            self.logger.error("mainWaterlinked : ERROR: pynlease specify correct ip address for Waterlinked GPS : {}".format(water_ip))
            self.script_conf['status'] = "mainWaterlinked : ERROR: pynlease specify correct ip address for Waterlinked GPS : {}".format(water_ip)
            sys.exit(1)



# Create global singleton used by the program
global TrackingSettings
TrackingSettings = CTrackingSettings()
