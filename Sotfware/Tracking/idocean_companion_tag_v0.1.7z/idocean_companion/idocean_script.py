#!/usr/bin/env python
# Accord argument parsing
"""
Usage:
    idocean_script [options]

Script dedicated to run with waterlinked and gps to control the pixhawk
in follow me mode.
Fork and adapted from idocean_ihm Tkinter

Type -h for more help


options:
  --loglvl LVL                  Log level (INFO, DEBUG, ERROR)
  -v --verbose                  Verbose mode
  -h --help                     Help menu
  --output_folder PATHSAV         Path dedicated to save file
  --offline                     Process image offline


Version:
    1.0


Author:
    IDOCEAN
"""
__author__ = "IDOCEAN + CoXpert"
__copyright__ = "IDOCEAN"
__credits__ = ["FOURNIER Geoffrey"]

__license__ = "XXX"
__version__ = "1.0"
__maintainer__ = "GFO"
__email__ = "fournier.geoffrey77@gmail.com"

import os
import sys
import traceback
import time
import math

from docopt import docopt
from dronekit import LocationGlobalRelative

from settings.settings import TrackingSettings as s
from communication.board_methods import TrackingBoard
from communication.vessel_data import VesselNAV, retrieve_vessel
from communication.serial_methods import SerialReader
from communication.requests_methods import get_global_position, set_position_master
from communication.udp_methods import is_valid_ipv4_address, is_valid_port
import threading

TEST_POS = {
    "lat": -21,
    "lon": 55.5,
    "orientation": 250
}
# Gps is connected directly to the pixhawk => read from mavlink
def main():
    '''
    Main Fonction of the scrip dedicated to start process
    '''
    s.logger.info("Main Start")
    if is_valid_ipv4_address(s.script_conf["waterlink_ip"]):
        url_webgui = "http://{}".format(s.script_conf["waterlink_ip"])
        s.logger.info("waterlink url : {}".format(url_webgui))
    else:
        s.logger.error("ERROR: please specify correct ip address for Waterlinked GPS : {}".format(s.script_conf["waterlink_ip"]))
        sys.exit(1)

    tBoard = TrackingBoard()
    tBoard.display_basic_info()

    isRunning = True    
    last_checkpoint = None
    while isRunning:
        if tBoard.vehicle.mode.name != "GUIDED":
            print("Waiting GUIDED mode ...")
            time.sleep(2)
        else:
            # Read the GPS position from Mavlink
            board_pos = tBoard.vehicle.location.global_relative_frame
            orientation = tBoard.vehicle.heading
            s.logger.info("GPS Read from Dronekit (mavlink) : lat : {}  | Long : {} | Alti : {} , Heading : {}".format(board_pos.lat, board_pos.lon, board_pos.alt, orientation))

            try: 
                s.logger.info("SET POSITION MASTER")
                ret = set_position_master(url_webgui, board_pos.lat, board_pos.lon, orientation)
            except Exception as e:
                s.logger.error("Set Waterlinked position error: {} ".format(e))
            
            turtle_pos = None
            turtle_pos = get_global_position(url_webgui)
            if turtle_pos is None:
                s.logger.warning("ERROR to read Global position from MAVLINK Gui")
                continue # Comment if test_pos used

            s.logger.info("Waterlinked global position (read from mavlink) : lat : {}  | Long : {} | ".format(turtle_pos["lat"], turtle_pos["lon"]))

            if last_checkpoint is None:
                # First checkpoint sent
                dest = LocationGlobalRelative(turtle_pos["lat"], turtle_pos["lon"], 0)
                last_checkpoint = turtle_pos
                print("Going to: {}".format(dest))
                # A better implementation would only send new waypoints if the position had changed significantly
                tBoard.vehicle.simple_goto(dest)
                continue
                
            # Once we have a valid location (see gpsd documentation) we can start moving our vehicle around
            diff_lat = abs(turtle_pos["lat"] - last_checkpoint["lat"])
            diff_lon = abs(turtle_pos["lon"] - last_checkpoint["lon"])
            if (diff_lat > s.script_conf["min_diff_lat"]) and (diff_lon > s.script_conf["min_diff_lon"]):
                dest = LocationGlobalRelative(turtle_pos["lat"], turtle_pos["lon"], 0)
                last_checkpoint = turtle_pos
                s.logger.info("New waypoint sent : {}".format(dest))
                # A better implementation would only send new waypoints if the position had changed significantly
                tBoard.vehicle.simple_goto(dest)
            else:
                s.logger.info("No new waypoint sent : diff_lat : {} < {} & diff_lon : {} < {}".format(diff_lat, 
                                                                                                 s.script_conf["min_diff_lat"], 
                                                                                                 diff_lon, 
                                                                                                 s.script_conf["min_diff_lon"])) 
        time.sleep(2)
    return


if __name__ == '__main__':
    # Here load the JSON FILE used for the main conf of the project
    try:
        # Manage init var + init counter and argument parsing
        start_time = time.time()
        args = docopt(__doc__)  # retrieve args based on initial info page

        # Load s from JSON and after from args
        s.load_from_json()
        s.load_from_args(args)

        print("Verbose state {}".format(s.script_conf["verbose"]))

        if os.path.isdir(s.script_conf["path_output_save"]):
            print("Directory for path to save exist : {}".format(
                s.script_conf["path_output_save"]))
        else:
            print("Directory for path to save not exist, create one at : \
                    {}".format(s.script_conf["path_output_save"]))
            os.makedirs(os.path.relpath(s.script_conf["path_output_save"]))

        s.script_conf["path_output_save"] = s.script_conf["path_output_save"] + time.strftime("%Y%m%d-%H%M%S") + '/'
        print("Create sub directory with time stamp : {}".format(s.script_conf['path_output_save']))
        os.makedirs(os.path.relpath(s.script_conf["path_output_save"]))

        # Create logger now in order to used it as soon as possible
        s.create_logger()
        s.logger.info("Start FollowMe Application at {}".format(time.asctime()))
        s.logger.debug("Start with the following config : {}".format(s))

        # Run main program
        main()

        s.logger.info("End of the program at {}".format(time.asctime()))
        s.logger.info("Total time in minute : {}".format((time.time() - start_time) / 60.0))
        sys.exit(0)

    # Manage key interrupt
    except KeyboardInterrupt as e:
        if s.logger is not None:
            s.logger.error("Keyboard Interrupt")
            s.logger.error(str(e))
        else:
            print("Keyboard Interrupt")
        raise e

    # Manage system exist
    except SystemExit as e:
        if s.logger is not None:
            s.logger.error("System Exit")
            s.logger.error(str(e))
        else:
            print("System exit : {}".format(e))
        raise e

    # Manage all other Exception
    except Exception as e:
        print('ERROR, UNEXPECTED EXCEPTION')
        print(str(e))
        if s.logger is not None:
            s.logger.error("ERROR, Unexpected exception")
            s.logger.error(str(e))
            s.logger.error(traceback.print_exc())
        else:
            print("ERROR, Unexpected exception")
            print(str(e))
            print(traceback.print_exc())
        traceback.print_exc()
        os._exit(1)

    # Manage end of the program
    finally:
        if s.logger is not None:
            s.logger.info('Clean end')
        else:
            print("Clean end")
        del s
