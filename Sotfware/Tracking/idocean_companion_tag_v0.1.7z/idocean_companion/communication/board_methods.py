# Code used from nmeainput.py: https://github.com/waterlinked/examples/blob/master/nmeainput.py
# Credits to Kristian Hole, Waterlinked

"""
Fonction dedicated to communicate with mavlink
"""
import time
from dronekit import connect, VehicleMode, LocationGlobalRelative
import socket
import time
import sys

from settings.settings import TrackingSettings as s


class TrackingBoard(object):
    def __init__(self):
        try:
            # Create the connection
            #  Companion is already configured to allow script connections under the port 9000
            # Note: The connection is done with 'udpout' and not 'udpin'.
            #  You can check in http:192.168.1.2:2770/mavproxy that the communication made for 9000
            #  uses a 'udp' (server) and not 'udpout' (client).
            print('Connecting to vehicle on: udpout:0.0.0.0:9000')
            self.vehicle = connect(s.script_conf["mavlink"], wait_ready=True, timeout=300)
            self.vehicle.mode = VehicleMode("GUIDED")

        except Exception as err:
            self.ser = None
            str = "Serial connection error: {}".format(err)
            s.script_conf['status'] = str

            
    def arm_and_takeoff(self, aTargetAltitude):
        """
        Arms vehicle and fly to aTargetAltitude.
        """

        print("Basic pre-arm checks")
        # Don't let the user try to arm until autopilot is ready
        while not self.vehicle.is_armable:
            print(" Waiting for vehicle to initialise...")
            time.sleep(1)

            
        print("Arming motors")
        # Copter should arm in GUIDED mode
        self.vehicle.mode = VehicleMode("GUIDED")
        self.vehicle.armed = True    

        while not vehicle.armed:      
            print(" Waiting for arming...")
            time.sleep(1)

        print("Taking off!")
        self.vehicle.simple_takeoff(aTargetAltitude) # Take off to target altitude

        # Wait until the vehicle reaches a safe height before processing the goto (otherwise the command 
        #  after Vehicle.simple_takeoff will execute immediately).
        while True:
            print(" Altitude: ", self.vehicle.location.global_relative_frame.alt)      
            if self.vehicle.location.global_relative_frame.alt>=aTargetAltitude*0.95: #Trigger just below target alt.
                print("Reached target altitude")
                break
            time.sleep(1)

    def display_basic_info(self):
        # Connect to the Vehicle (in this case a UDP endpoint)
        print("Autopilot Firmware version: {}".format(self.vehicle.version))
        print("Autopilot capabilities (supports ftp): {}".format(self.vehicle.capabilities.ftp))
        print("Global Location: {}".format(self.vehicle.location.global_frame))
        print("Global Location (relative altitude): {}".format(self.vehicle.location.global_relative_frame))
        print("Local Location: {}".format(self.vehicle.location.local_frame))
        print("Attitude: {}".format(self.vehicle.attitude))
        print("Velocity: {}".format(self.vehicle.velocity))
        print("GPS: {}".format(self.vehicle.gps_0))
        print("Groundspeed: {}".format(self.vehicle.groundspeed))
        print("Airspeed: {}".format(self.vehicle.airspeed))
        print("Gimbal status: {}".format(self.vehicle.gimbal))
        print("Battery: {}".format(self.vehicle.battery))
        print("EKF OK?: {}".format(self.vehicle.ekf_ok))
        print("Last Heartbeat: {}".format(self.vehicle.last_heartbeat))
        print("Rangefinder: {}".format(self.vehicle.rangefinder))
        print("Rangefinder distance: {}".format(self.vehicle.rangefinder.distance))
        print("Rangefinder voltage: {}".format(self.vehicle.rangefinder.voltage))
        print("Heading: {}".format(self.vehicle.heading))
        print("Is Armable?: {}".format(self.vehicle.is_armable))
        print("System status: {}".format(self.vehicle.system_status.state))
        print("Mode: {}".format(self.vehicle.mode.name))    # settable
        print("Armed: {}".format(self.vehicle.armed))    # settable
        
