"""
Code dedicated to handle all UDP fonctionnalities
"""

from settings.settings import TrackingSettings as s
from math import floor


# Code used from nmeaoutput.py: https://github.com/waterlinked/examples#about-nmeaoutputpy
# Credits to Kristian Hole, Waterlinked
def checksum(sentence):
    """Calculate and return checsum for given NMEA sentence"""
    crc = 0
    for c in sentence:
        crc = crc ^ ord(c)
    crc = crc & 0xFF
    return crc


def get_data(url, stderr=False):
    import requests
    try:
        print("Request url {}".format(url))
        r = requests.get(url, timeout=0.2)
    except requests.exceptions.RequestException as exc:
        if stderr:
            s.logger.error("UDP Get_data Requests : Exception occured {}".format(exc))
        return None

    if r.status_code != requests.codes.ok:
        if stderr:
            s.logger.error("UDP Get_data requests  : Got error {}: {}".format(r.status_code, r.text))
        return None

    return r.json()


def set_position_master(url, latitude, longitude, orientation):
    import requests
    from requests.adapters import HTTPAdapter
    url = url + "/api/v1/external/master"
    requests.adapters.DEFAULT_RETRIES = 5
    payload = dict(lat=latitude, lon=longitude, orientation=orientation)

    print(url)
    r = requests.put(url, json=payload, timeout=3)
    if r.status_code != 200:
        s.logger.error("****** Set_position_master : Error: {} : {}".format(r.status_code, r.content))
        s.script_conf['status'] = "Set_position_master : Error: {} : {}".format(r.status_code, r.content)
        r.close()
    else:
        s.script_conf['status'] = "OK"
    return r

def get_global_position(base_url):
    return get_data("{}/api/v1/position/global".format(base_url))

def get_acoustic_filtered(base_url):
    return get_data("{}/api/v1/position/acoustic/filtered".format(base_url))

def get_master_position(base_url):
    return get_data("{}/api/v1/position/master".format(base_url))

def get_rov_lat(base_url):
    return get_data("{}/mavlink/GLOBAL_POSITION_INT/lat".format(base_url))
def get_rov_lon(base_url):
    return get_data("{}/mavlink/GLOBAL_POSITION_INT/lon".format(base_url))
def get_vessel_lat(base_url):
    return get_data("{}/mavlink/GPS_RAW_INT/lat".format(base_url))
def get_vessel_lon(base_url):
    return get_data("{}/mavlink/GPS_RAW_INT/lon".format(base_url))
def get_rov_alt(base_url):
    return get_data("{}/mavlink/GLOBAL_POSITION_INT/alt".format(base_url))
def get_rov_cap(base_url):
    return get_data("{}/mavlink/ATTITUDE/yaw".format(base_url))
def get_rov_pitch(base_url):
    return get_data("{}/mavlink/ATTITUDE/pitch".format(base_url))
def get_rov_roll(base_url):
    return get_data("{}/mavlink/ATTITUDE/roll".format(base_url))

def gen_gga(time_t, lat, lng, fix_quality, num_sats, hdop, alt_m, geoidal_sep_m, dgps_age_sec=None, dgps_ref_id=None):
    # Code is adapted from https://gist.github.com/JoshuaGross/d39fd69b1c17926a44464cb25b0f9828
    hhmmssss = '%02d%02d%02d%s' % (time_t.tm_hour, time_t.tm_min, time_t.tm_sec, '.%02d' if 0 != 0 else '')
    lat_abs = abs(lat)
    lat_deg = floor(lat_abs)
    lat_minsec = (lat_abs - lat_deg) * 60
    lat_min = floor(lat_minsec)
    lat_sec = round((lat_minsec - lat_min) * 10000000)
    lat_pole_prime = 'S' if lat < 0 else 'N'
    lat_format = '%02d%02d.%07d' % (lat_deg, lat_min, lat_sec)

    lng_abs = abs(lng)
    lng_deg = floor(lng_abs)
    lng_minsec = (lng_abs - lng_deg) * 60
    lng_min = floor(lng_minsec)
    lng_sec = round((lng_minsec - lng_min) * 10000000)
    lng_pole_prime = 'W' if lng < 0 else 'E'
    lng_format = '%03d%02d.%07d' % (lng_deg, lng_min, lng_sec)

    dgps_format = '%s,%s' % ('%.1f' % dgps_age_sec if dgps_age_sec is not None else '', '%04d' % dgps_ref_id if dgps_ref_id is not None else '')

    result = 'GPGGA,%s,%s,%s,%s,%s,%d,%02d,%.1f,%.1f,M,%.1f,M,%s' % (hhmmssss,
                                                                     lat_format,
                                                                     lat_pole_prime,
                                                                     lng_format,
                                                                     lng_pole_prime,
                                                                     fix_quality,
                                                                     num_sats,
                                                                     hdop,
                                                                     alt_m,
                                                                     geoidal_sep_m,
                                                                     dgps_format)
    crc = checksum(result)
    return '$%s*%0.2X' % (result, crc)


'''
1 => $PRAVE : Raveon Proprietary Header
2 => From ID : The ID of the transponder that transmitted its position over the air. It is a decimal number, 0 –9999
3 => To ID : The ID that this position report was sent to. It is a decimal number, 0 –9999.
id = 0 ==> ROV
id = 1 ==> Boat
id = 2 ==> Globalmapper ID
4 => Latitude : dddmm.mmmm format. It is signed. + is north, -is south.  No sign means north. Note: typically there are 4 decimal places, but as few as 0 decimal places are possible.  Null fieldif no GPS lock.
5 => Longitude : dddmm.mmmm format. It is signed. + is east, -is west.  No sign means east. Note: typically there are 4 decimal places, but as few as 0 decimal places are possible.  Null field if no GPS lock.
6 => UTC time : The UTC time at the time the transmission was made.  Hhmmss format. Null field if no GPS lock.
7 => GPS Status : 0=not valid position.  1=GPS locked and valid position.  2=Differential or WAAS fix.
8 => Num Satellites : The number of satellites in view
9 => Altitude : The altitude in meters.  Null field if no GPS lock.
10 => Temperature : The internal temperature of the RV-M7 in degrees C. Typically this is 5-20 degrees above ambient.
11 => Voltage : Input voltage to the device that sent this position.
12 => IO status : A decimal number representing the binary inputs.
13 => RSSI : The signal-strength of this message as measured by the receiver, in dBm. Note, if the message went through a repeater, it is the signal lever of the repeated message.
14 => Speed : The speed of the device in km/hour, 0-255
15 => Heading : The heading of the device 0-360 degrees
16 => Status : Status flags received from the device.  Not all products support generating all status flag codes. NULL means no alerts.  “P” means a proximity alert. “M” means man-down alert“A” General alert, usually due to pressing an alert button“C” Critical alert, usually due to pressing and holding alert button“I” Impact alert“V”  Vibration“S” Service required on product“X” Gas fume sensor detects CO or other gas.
17 => Spare : A spare field.  May be used for UTC date in the future. Typically NULL.
18 =>  * The “*” NMEA end-of-message identifier.
19 => Checksum : The NMEA 0183 checksum.
'''
def gen_prave(id, time_t, lat, lng, fix_quality, num_sats, alt_m, temp, volt, IOStatus, rssi, speed, head):
    # Code is adapted from https://gist.github.com/JoshuaGross/d39fd69b1c17926a44464cb25b0f9828
    hhmmssss = '%02d%02d%02d%s' % (time_t.tm_hour, time_t.tm_min, time_t.tm_sec, '.%02d' if 0 != 0 else '')
    lat_abs = abs(lat)
    lat_deg = floor(lat_abs)
    lat_minsec = (lat_abs - lat_deg) * 60
    lat_min = floor(lat_minsec)
    lat_sec = round((lat_minsec - lat_min) * 10000000)
    lat_pole_prime = 'S' if lat < 0 else 'N'
    if lat_pole_prime == 'S':
        lat_format = '-%02d%02d.%07d' % (lat_deg, lat_min, lat_sec)
    else:
        lat_format = '%02d%02d.%07d' % (lat_deg, lat_min, lat_sec)

    lng_abs = abs(lng)
    lng_deg = floor(lng_abs)
    lng_minsec = (lng_abs - lng_deg) * 60
    lng_min = floor(lng_minsec)
    lng_sec = round((lng_minsec - lng_min) * 10000000)
    lng_pole_prime = 'W' if lng < 0 else 'E'

    if lat_pole_prime == 'W':
        lng_format = '-%03d%02d.%07d' % (lng_deg, lng_min, lng_sec)
    else:
        lng_format = '%03d%02d.%07d' % (lng_deg, lng_min, lng_sec)


#    result = 'PRAVE,%s,%s,%s,%s,%s,%d,%02d,%.1f,%.1f,M,%.1f,M,%s' % (hhmmssss, lat_format, lat_pole_prime, lng_format, lng_pole_prime, fix_quality, num_sats, hdop, alt_m, geoidal_sep_m, dgps_format)
    result = 'PRAVE,%s,%s,%s,%s,%s,%d,%02d,%.1f,%.1f,%.1f,%d,%s,%d,%.1f,,,' % ("000" + str(id), "0002",
                                                                           lat_format, lng_format, hhmmssss,
                                                                           fix_quality, num_sats,
                                                                           alt_m, temp, volt, IOStatus, rssi, speed, head)
    crc = checksum(result)


    return '$%s*%0.2X' % (result, crc)


