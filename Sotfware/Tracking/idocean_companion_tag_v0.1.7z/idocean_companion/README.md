# idocean-rover

Project dedicated to IdOcean for BlueRov2

# TODO : 
Desktop.ini file move to launcher, check if working but instead of absolute
path used relative path

# Install : 

	git clone https://bitbucket.org/Schade77/idocean-rover.git

## Install conda on your system:
https://docs.conda.io/projects/conda/en/latest/user-guide/install/

## Config conda forge :
  Take a look at https://conda-forge.org/
  conda config --add channels conda-forge
  conda config --set channel_priority strict

## create conda environment :
  conda create --name ROVER --file condaEnvironmentFile.txt

## externnal dependency imported by condaEnvironmentFile.txt:
# packages in environment at /home/schade/anaconda3/envs/rover:
#
# Name                    Version                   Build  Channel
_libgcc_mutex             0.1                        main  
astroid                   2.2.5                     <pip>
ca-certificates           2019.3.9             hecc5488_0    conda-forge
certifi                   2017.1.23                py34_0    conda-forge
docopt                    0.6.2                      py_1    conda-forge
dodgy                     0.1.9                     <pip>
future                    0.17.1                    <pip>
giflib                    5.1.7                h516909a_1    conda-forge
idna                      2.8                       <pip>
imutils                   0.5.2                     <pip>
iso8601                   0.1.12                    <pip>
isort                     4.3.21                    <pip>
jpeg                      9c                h14c3975_1001    conda-forge
lazy-object-proxy         1.4.2                     <pip>
leptonica                 1.76.0            h7f84942_1005    conda-forge
libgcc-ng                 7.3.0                hdf63c60_0  
libpng                    1.6.37               hed695b0_0    conda-forge
libstdcxx-ng              8.2.0                hdf63c60_1  
libtiff                   4.0.10            h648cc4a_1001    conda-forge
libwebp                   1.0.2                h99fbfcb_2    conda-forge
lxml                      4.3.0                     <pip>
mccabe                    0.6.1                     <pip>
ncurses                   5.9                          10    conda-forge
numpy                     1.16.4                    <pip>
opencv-contrib-python     4.0.1.24                  <pip>
openjpeg                  2.3.1                h58a6597_0    conda-forge
openssl                   1.0.2r               h14c3975_0    conda-forge
pep8-naming               0.4.1                     <pip>
Pillow                    5.4.1                     <pip>
pip                       19.0.1                    <pip>
pip                       9.0.1                    py34_0    conda-forge
prospector                1.1.7                     <pip>
pycodestyle               2.4.0                     <pip>
pycscope                  1.2.1                     <pip>
pydocstyle                4.0.1                     <pip>
pyflakes                  1.6.0                     <pip>
pylint                    2.3.1                     <pip>
pylint-celery             0.3                       <pip>
pylint-django             2.0.10                    <pip>
pylint-flask              0.6                       <pip>
pylint-plugin-utils       0.5                       <pip>
pymavlink                 2.3.4                     <pip>
pynmea2                   1.15.0                    <pip>
pyserial                  3.4                        py_2    conda-forge
pytesseract               0.2.6                     <pip>
python                    3.4.5                         2    conda-forge
PyWavelets                1.0.3                     <pip>
PyYAML                    3.13                      <pip>
readline                  6.2                           0    conda-forge
requests                  2.12.4                   py34_0    conda-forge
requirements-detector     0.6                       <pip>
setoptconf                0.2.0                     <pip>
setuptools                32.3.1                   py34_0    conda-forge
six                       1.12.0                    <pip>
snowballstemmer           1.9.1                     <pip>
sqlite                    3.13.0                        1    conda-forge
tesseract                 4.0.0             h47f2187_1001    conda-forge
tk                        8.5.19                        2    conda-forge
typed-ast                 1.4.0                     <pip>
typing                    3.7.4.1                   <pip>
urllib3                   1.24.1                    <pip>
wheel                     0.29.0                   py34_0    conda-forge
wrapt                     1.11.2                    <pip>
xz                        5.2.4             h14c3975_1001    conda-forge
zlib                      1.2.11            h14c3975_1004    conda-forge

opencv-contrib-python has been choose at startup (test purpose, minimal
installation shall be defined later): installation with conda forge
Opencv used with tkinter for IHM

## Sphynx documentation :
	http://www.sphinx-doc.org/

  not yet compiled and used ! 
	pip install Sphynx
	if new project : sphinx-quickstart (otherwise already done and commited)
	not already done !


## Useful links :

https://www.bluerobotics.com/store/rov/bluerov2/bluerov2/
https://github.com/topics/bluerov2


* MAVLink ground station (http://ardupilot.github.io/MAVProxy/) :
	
	https://github.com/ArduPilot/MAVProxy/tree/master/MAVProxy 
	
	Requirements :
	sudo apt-get install python-dev python-opencv python-wxgtk3.0 python-pip python-matplotlib python-pygame python-lxml python-yaml
	
	or used public Pypi (work mac should be the same on linux)
	
	pip install wxPython
	pip install gnureadline
	pip install billiard
	pip install numpy pyparsing
	pip install MAVProxy
	
(On some older Linux systems, python-wxgtk3.0 may be instead named as python-wxgtk2.8.)

	pip install MAVProxy (don't forget to activate environment before call it)

Depending on user and system settings, there may be some extra configuration required.
If not already set, MAVProxy needs to be on the system path:

	echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bashrc

The user permissions may also need to be changed to allow access to serial devices:

	sudo adduser <username> dialout

The system will need to be logged out and logged back in again to apply the above two changes.


## Project initial structure:
.
├── communication
│   ├── waterlinked_comm.py
│   ├── forward_depth.py
│   ├── rov_NMEA.py
│   ├── serial_methods.py
│   ├── udp_methods.py
│   └── vessel_data.py
├── config
│   └── windows_setup_first_time.sh
├── doc
│   ├── Organigramme ROV - inspection.pdf
│   └── port_description.txt
├── exec
│   ├── executing.py
│   └── tools.py
├── ihm
│   ├── mainWindow.py
│   ├── tabConf.py
│   ├── tabWaterlinked.py
│   ├── tabLog.py
│   ├── tab.py
│   ├── tabVideo.py
│   └── toolIhm.py
├── image_processing
│   ├── image_enhance.py
│   ├── offline_process.py
│   ├── shapeDetector.py
│   └── video_capture.py
├── img
│   ├── icon.gif
│   └── icon.png
├── launcher
│   ├── desktop.ini
│   ├── setup.desktop
│   └── setup.desktop.bak
├── MAVProxy
├── README.md
├── settings.json
├── settings.py
├── setup.desktop
└── startihm.py

\n
wmctrl : interact with a EWMH/NetWM compatible X Window Manager. (interact with X window manager)
xdotool : simulate keybord input and mouse activity (move and resize windows)
simplescreenrecorder : used to record progreams and games
pyserial : manage the serial communication
requests : bibliothèque HTTP Python pour UDP


