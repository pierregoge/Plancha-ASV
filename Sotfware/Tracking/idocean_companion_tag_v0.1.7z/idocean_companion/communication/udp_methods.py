"""
Code dedicated to handle all UDP fonctionnalities
"""

import socket
import time

from settings.settings import TrackingSettings as s

def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  # not a valid address
        return False

    return True


def is_valid_port(port):
    return_value = False
    if port >= 0 and port <= 99999:
        return_value = True

    return return_value


def send_udp(sock, ip, port, message):
    if message is not None:
        message = message.encode(encoding='ascii')
        sock.sendto(message, (ip, int(port)))
        s.script_conf['status'] = 'OK'
    else:
        s.logger.error("Not possible to send UDP message () to {}:{}".format(ip, port))
        s.script_conf['status'] = "Not possible to send UDP message () to {}:{}".format(ip, port)


class SetupException(Exception):
    pass


class UDPReader(object):
    def __init__(self, host, port):
        try:
            self.host = host
            self.port = port
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((host, port))
            s.logger.info("Create socket to IP: " + str(host) + " PORT: " + str(port))
            s.script_conf['status'] = 'OK'
        except socket.error as err:
            s.logger.error("UDP setup: Could not bind to {}:{}. Error: {}".format(host, port, err))
            s.script_conf['status'] = "UDP setup: Could not bind to {}:{}. Error: {}".format(host, port, err)
            self.sock.close()

    def __del__(self):
        self.sock.close()

    def iter(self, flag=[True]):
        while(flag[0]):
            try:
                data, addr = self.sock.recvfrom(1024, socket.MSG_DONTWAIT)
#    #            data, addr = self.sock.recvfrom(1024)
                if not data:
                    break
                # Add newline if not present
                if data[-1] != "\n":
                    data = data + "\n".encode()
                yield data
            except Exception as e:
                s.logger.debug("Wait data from {}:{}".format(self.host, self.port))
                time.sleep(0.1)
                pass
        self.sock.close()
