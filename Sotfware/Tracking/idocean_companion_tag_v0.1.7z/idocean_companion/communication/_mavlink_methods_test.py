# Code used from nmeainput.py: https://github.com/waterlinked/examples/blob/master/nmeainput.py
# Credits to Kristian Hole, Waterlinked

"""
Fonction dedicated to communicate with mavlink
"""
import time
# Import mavutil
from pymavlink import mavutil


from settings.settings import rovIhmSettings as s


class Mavlink(object):
    def __init__(self):
        try:
            # Create the connection
            #  Companion is already configured to allow script connections under the port 9000
            # Note: The connection is done with 'udpout' and not 'udpin'.
            #  You can check in http:192.168.1.2:2770/mavproxy that the communication made for 9000
            #  uses a 'udp' (server) and not 'udpout' (client).
            s.script_conf['status'] = 'OK'
            self.master = mavutil.mavlink_connection('udpout:0.0.0.0:9000')
            # Send a ping to start connection and wait for any reply.
            #  This function is necessary when using 'udpout',
            #  as described before, 'udpout' connects to 'udpin',
            #  and needs to send something to allow 'udpin' to start
            #  sending data.
            self.wait_conn()

        except Exception as err:
            self.ser = None
            str = "Serial connection error: {}".format(err)
            s.script_conf['status'] = str

    def iter(self, flag=[True]):
        if self.master is not None:
            while flag[0]:
                yield self.master.recv_match().to_dict()
    def test_loop(self):
        # Get some information !
        while True:
            try:
                print(self.master.recv_match().to_dict())
            except:
                pass
            time.sleep(0.1)
        
    
    def wait_conn(self):
        """
        Sends a ping to stabilish the UDP communication and awaits for a response
        """
        msg = None
        while not msg:
            self.master.mav.ping_send(
                int(time.time() * 1e6), # Unix time in microseconds
                0, # Ping number
                0, # Request ping of all systems
                0 # Request ping of all components
            )
            msg = self.master.recv_match()
            time.sleep(0.5)

