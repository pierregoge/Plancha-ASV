#
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2019 schade <schade@schadelin-System>
#
# Distributed under terms of the MIT license.
# File dedicated to manage the communication with ROV and waterlinked device

"""This process is dedicated to manage the communication with the Waterlinked
software.
"""
import os
import sys
import logging
import socket
import pynmea2
import threading
import time
import serial

from communication.vessel_data import VesselNAV, retrieve_vessel
from communication.rov_data import retrieve_rov_data
from communication.udp_methods import is_valid_port, is_valid_ipv4_address, send_udp, UDPReader
from communication.requests_methods import set_position_master, get_global_position
from communication.requests_methods import gen_gga, gen_prave, get_rov_alt, get_rov_cap, get_rov_lat, get_rov_lon, get_rov_pitch, get_rov_roll, get_vessel_lat, get_vessel_lon
from communication.serial_methods import SerialReader
from communication.forward_depth import set_depth

from settings.settings import TrackingSettings as s

logging.getLogger("requests").setLevel(logging.WARNING)

def mainWaterlinked(bluerov_ip, bluerov_mavlink_port,
               monitor_ip, water_ip,
               serial_in_cap, serial_baud_cap,
               serial_in_gps, serial_baud_gps,
               serial_out, serial_baud_out,
               flag=[True]):
    """
    Main loop of the thread dedicated to init variables and manage main loop
    """
    s.logger.info("mainWaterlinked : Main fledermaus process Initialization")

    # Create log file dedicated to store data acquisition
    logpath = s.script_conf['path_output_save'] + 'flederLog.log'

    if not os.path.isfile(logpath):
        with open(logpath, 'w'):
            pass

    s.logger.info("mainWaterlinked : Fledermaus : Log creation {} ...".format(logpath))

    flederLog = logging.getLogger('fleder_data')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logHandler = logging.FileHandler(logpath)

    flederLog.setLevel(logging.INFO)
    logHandler.setLevel(logging.INFO)
    logHandler.setFormatter(formatter)
    flederLog.addHandler(logHandler)

    logpathD = s.script_conf['path_output_save'] + 'flederDepth.log'

    if not os.path.isfile(logpathD):
        with open(logpathD, 'w'):
            pass

    s.logger.info("mainWaterlinked : Fledermaus : Log Depth creation {} ...".format(logpath))

    depthLog = logging.getLogger('fleder_depth')
    formatterD = logging.Formatter('%(asctime)s ; %(message)s')
    logHandlerD = logging.FileHandler(logpathD)
    depthLog.setLevel(logging.INFO)
    logHandlerD.setLevel(logging.INFO)
    logHandlerD.setFormatter(formatterD)
    depthLog.addHandler(logHandlerD)

    # Check monitor IP (ASUS ip)
    if not(is_valid_ipv4_address(monitor_ip)):
        s.logger.error("mainWaterlinked : ERROR: Please specify either serial port or UDP port to use in s.json or in main args")
        s.script_conf['status'] = "mainWaterlinked : ERROR: Please specify either serial port or UDP port to use in settings.json or in main args"
        sys.exit(1)

    # Check bluerov ip address & port not empty
    if is_valid_ipv4_address(bluerov_ip):
        bluerov_mavlink_port = int(bluerov_mavlink_port)
        if is_valid_port(bluerov_mavlink_port):
            # Ip / Port OK : Prepare web gui address to mavlink
            url_mavlink_webgui = "http://{}:{}".format(bluerov_ip,
                                                       bluerov_mavlink_port)
            s.logger.info("MainWaterlinked : Mavlink GUI url : \
                                 {}".format(url_mavlink_webgui))
        else:
            s.logger.error("MainWaterlinked : ERROR: Port mavlink \
                                  incorrect (should be 4777): \
                                  {}".format(bluerov_mavlink_port))
            s.script_conf['status'] = "MainWaterlinked : ERROR: \
                Port mavlink incorrect (should be 4777): \
                {}".format(bluerov_mavlink_port)
            sys.exit(1)
    else:
        s.logger.error("MainWaterlinked : ERROR: Ip address bluerov \
                              incorect (should be 192.168.2.2): \
                              {}".format(bluerov_ip))
        s.script_conf['status'] = "MainWaterlinked : ERROR: \
            Ip address bluerov incorrect (should be 192.168.2.2): \
            {}".format(bluerov_ip)
        sys.exit(1)


    # Check warterlinked ip adress
    if is_valid_ipv4_address(water_ip):
        url_webgui = "http://{}".format(water_ip)
        s.logger.info("mainWaterlinked : waterlink url : {}".format(url_webgui))
    else:
        s.logger.error("mainWaterlinked : ERROR: pynlease specify correct ip address for Waterlinked GPS : {}".format(water_ip))
        s.script_conf['status'] = "mainWaterlinked : ERROR: pynlease specify correct ip address for Waterlinked GPS : {}".format(water_ip)
        sys.exit(1)

    if serial_in_cap != "":
        s.logger.info("mainWaterlinked : Source Serial in {} at {} baud (dedicated to retrieve Vessel Cap)".format(serial_in_cap, serial_baud_cap))
        serial_reader_cap = SerialReader(serial_in_cap, serial_baud_cap)

    if serial_in_gps != "":
        s.logger.info("mainWaterlinked : Source Serial in {} at {} baud (dedicated to retrieve Vessel GPS)".format(serial_in_gps, serial_baud_gps))
        serial_reader_gps = SerialReader(serial_in_gps, serial_baud_gps)

    if serial_out != "":
        s.logger.info("mainWaterlinked : Serial ouput port to QGIS: {}".format(serial_out))
        try:
            serialOut = serial.Serial(serial_out, serial_baud_out)
        except Exception as e:
            s.logger.error("mainWaterlinked : Exception to open serial output to monitor PC ({})".format(e))
            s.script_conf['status'] = "mainWaterlinked : Exception to open serial output to monitor PC ({})".format(e)
    else:
        s.logger.error("mainWaterlinked : Serial output of the application not defined")
        s.script_conf['status'] = "mainWaterlinked : Serial output of the application not defined"
        sys.exit(1)

    # Build writer UDP socket tosend data to fleder
    writerFleder = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    writerDepthMon = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.logger.info("MainFlder : Take Care, IP from MAVLINK ROV is static (0.0.0.0) not possible to change it from config file ")

    # create Cap Vessel reader (Serial)
    vessel_cap = VesselNAV()
    tVesselRead_cap = threading.Thread(target=retrieve_vessel, args=(serial_reader_cap, None, vessel_cap, flag))

    # create GPS Vessel reader (Serial)
    vessel_gps = VesselNAV()
    tVesselRead_gps = threading.Thread(target=retrieve_vessel, args=(serial_reader_gps, None, vessel_gps, flag))

    # Configure thread Deamon
    tVesselRead_cap.setDaemon(True)
    tVesselRead_gps.setDaemon(True)

    # Start reader process
    tVesselRead_cap.start()
    tVesselRead_gps.start()

    s.script_conf['status'] = 'OK'
    countSerialError = 0
    while flag[0]:
        # Update vessel waterlinked
        cVesselCap = vessel_cap.get_cap()  # from vessel
        cVesselPos = vessel_gps.get_pos()  # from vessel
        cVesselH = vessel_gps.get_haut()   # from vessel

        try:
            set_position_master(url_webgui + '/api/v1/external/master', cVesselPos[0], cVesselPos[1], cVesselCap)
        except Exception as e:
            s.logger.error("Set_position_master : Error: {} ".format(e))
            s.script_conf['status'] = "Set_position_master : Error: {} ".format(e)
            flag[0] = False
            # raise e

         # Read Rov data from mavlink webgui
        rov_data = retrieve_rov_data(url_mavlink_webgui)
        s.logger.info("ROV data : {}".format(rov_data))

        if rov_data is None:
            s.logger.warning("ERROR to read data from MAVLINK Gui")
            s.script_conf['status'] = "ERROR to read data from MAVLINK GUI"
        else:
            # Retrieve LAT/LONG from Waterlinked
            posRov = None
            posRov = get_global_position(url_webgui)
            s.logger.info("posRov")
            s.logger.info(posRov)
            if posRov is not None:
                s.logger.info("Current ROV from Waterlink position lat:{} lon:{}".format(posRov["lat"], posRov["lon"]))
                s.script_conf['status'] = 'OK'
                # read value
                cRovDepth = abs(rov_data["depth"])  # from ROV
                cRovCap = rov_data['cap']

                if s.net_conf["waterlinked"]["forward_depth"]:
                    set_depth(url_webgui + '/api/v1/external/depth', cRovDepth)
                    s.logger.info("Send depth manualy")

                # Forward data to Serial for monitor QGIS application
                if s.script_conf['en_prave']:
                    trameRov = gen_prave(0, time.gmtime(), posRov['lat'], posRov['lon'], 1, 10, cRovDepth, 0, 13.0, 3, "-83", 0, cRovCap)
                    trameRov += "\r\n"
                    trameVessel = gen_prave(1, time.gmtime(), cVesselPos[0], cVesselPos[1], 1, 10, 0, 30, 13.0, 3, "-83", 0, cVesselCap)
                    trameVessel += "\r\n"
                else:
                    # Forward data to Serial for monitor QGIS application
                    trameRov = gen_gga(time.gmtime(), posRov["lat"], posRov["lon"], 4, 10, 1, 0, 0) #added 1 argument to fixed quality or position was rejected by other software
                    trameRov += "\r\n"

                serialOut.write(trameRov.encode(encoding='ascii') )
                if s.script_conf['en_prave']:
                    serialOut.write(trameVessel.encode(encoding='ascii') )

                send_udp(writerFleder, "192.168.2.254", 25104, trameRov)
    #            send_udp(writerFleder, "192.168.2.254", 25104, trameVessel)


                data_str = """
                Vessel (lat, long, cap) : {}, {}, {}
                Rov (lat, long, cap) : {}, {}, {}
                Rov Depth : {}     | Rov temp : {}
                """.format(cVesselPos[0], cVesselPos[1], cVesselCap,
                        posRov['lat'], posRov['lon'], cRovCap,
                        cRovDepth, 0)

                flederLog.info(data_str)
                depthStr = '{};'.format(cRovDepth)
                depthLog.info(depthStr)
            else:
                s.logger.warning("Error to retrieve data from ROV Waterlinked WebGUI")
                s.script_conf['status'] = "Error to retrieve data from ROV Waterlinked WebGUI"
                time.sleep(2)


        time.sleep(0.1)

    return


#if __name__ == "__maindepth__":
#    #mainWaterlinked()
